package com.propen.resismiop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResismiopApplicationTests {

	@Test
	void contextLoads() {
	}

}
