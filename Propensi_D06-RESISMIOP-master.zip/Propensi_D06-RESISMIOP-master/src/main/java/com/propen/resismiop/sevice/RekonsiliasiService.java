package com.propen.resismiop.sevice;

public interface RekonsiliasiService {
    Boolean rekonsilias (Long nomorTransaksiBank, Long nomorTransaksiBapenda);
}
